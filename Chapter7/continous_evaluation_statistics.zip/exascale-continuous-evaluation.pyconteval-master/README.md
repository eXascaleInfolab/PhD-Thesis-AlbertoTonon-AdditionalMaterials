pycont_eval
===========

`pycont_eval` extends [`pytrec_eval`](https://github.com/XI-lab/pytrec_eval/edit/master/README.md) by adding 
functions to compute Fairness Score, Opportunistic Number of Relevant Documents, and Opportunistic pooling.

Loading Data
------------
The `pycont_eval` module contains a class that wraps TREC-runs and keeps information on their unjudged documents.

In order to load a TREC-run:

* first, use the class QRels to load the relevance judgements from a TREC-qrels like file

  `qrels = pycont_eval.QRels(<fileName>)`

* then, use the class CERun to load a TREC-run from a file

  `run = pycont_eval.CERun(<fileName>, qrels)`


Continuous Evaluation Tools
------------

* In order to compute the _Fairness Score_ you can use the function `evaluate` in the following way:

  `fairness_score = pycont_eval.evaluate(run, qrels, pycont_eval.fairness)`.
  
  As in `pytrec_eval`, you can specify the optional parameter `detailed` to obtain the Fairness Score of each topic.
  For example:

  `fairness_score, fairness_details = pycont_eval.evaluate(run, qrels, pycont_eval.fairness, detailed=True)`

  returns a pair, where the first element is the mean Fairness Score, and the second element is 
  a dictionary specifying the Fairness Score of each topic (the topic id is the key).


* _Opportunistic Number of Relevant Documents_ can be computed by using the `oppNumRelevant` function that takes 5 parameters:
  1. the desired improvement over the baseline run;
  2. the baseline run;
  3. the new run;
  4. a qrels object;
  5. the identifier of the topic one wants to analyse.

  The function returns a pair whose first element is a list `l` of opportunistically selected documents 
  (`len(l)` is the Opportunistic Number of Relevant Documents), and whose second element is the 
  Optimistic Effectiveness computed by assuming that all the selected documents are relevant.

  Example:
    `docs, improvement = pycont_eval.oppNumRelevant(0.25, baseline, newrun, qrels, 'q5')`.

* _Opportunistic Number of Relevant Documents_  can be generalized over a whole run 
  (thus, taking into consideration many topics). 
  The function `avgOppNumRelevants` returns the average Opportunistic Number of 
  Relevant Documents and the average Optimistic Effectiveness computed over all topics.

  Example:
    `avgNrelevants, avgOptImprovement = avgOppNumRelevants(0.25, baseline, newrun, qrels)`


Opportunistic Pooling
------------
`pycont_eval` implements to variants of Opportunistic Pooling:

1. _Fixed number of judgements_. 
  By using the function `opportunisticPooling_fixedJudgments` a fixed number of documents is opportunistically selected 
  to be part of the pool of documents to judge.
  
  For example, after the statement
    `docs = opportunisticPooling_fixedJudgments(50, baseline, newrun, qrels)`,
  `docs` is a dictionary specifying, for each topic, 50 oppurtunistically selected documents to judge.

2. _Improvement on AP with judgement limit_.
  By using the function `opportunisticPooling_APImprovement` it is possible to specify both a desired Optimistic Effectiveness
  to try to reach and a maximum number of judgements available for each topic.
  The algorithm will select a new document to be judged until the desired Optimistic Effectiveness or 
  the judgement limit is reached.
  
  For example, in this call
    `opportunisticPooling_APImprovement(0.25, 10, baseline, newrun, qrels)`,
  the Optimistic Effectiveness we want to reach is 0.25*AP(baseline) and we want to make at most 10 judgements per topic.
  
  



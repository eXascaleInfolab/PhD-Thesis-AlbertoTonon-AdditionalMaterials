
from pytrec_eval import *

class CERun(TrecRun):
    """
    Adds AP improvement to TrecRun.
    For the moment only works on a single topic.
    """
    # deltas[topicId][docId] = increaseInAP starts from 1
    deltas = None
    # a dictionary of lists unjlist[topicId] = [(docId, rank)] of unjudged documents
    unjudgedList = None
    # a dictionary of sets docSet[topicId] = {docIds}
    docSet = None
    # a dictionary of sets newRelevants[topicId] = {relevant documents in qrels + new relevants}
    relevants = None

    def reset(self, qrels):
        if qrels == None: return

        self.deltas = {}
        self.unjudgedList = {}
        self.docSet = {}
        self.relevants = {}
        for topicId in self.getTopicIds():
            self.unjudgedList[topicId] = [(docId, rank)
                                          for rank, (docId, _, _) in enumerate(self.getEntriesBy(topicId), start=1)
                                          if not qrels.isJudged(topicId, docId)] #already ordered by rank
            self.docSet[topicId] = {docId for docId, _, _ in self.getEntriesBy(topicId)}
            self.relevants[topicId] = qrels.getAllRelevants(topicId)
            self._initDeltas(topicId, qrels)
#        print('resetted run', self.name)

    def __init__(self, trecRunFile, qrels):
        super(CERun, self).__init__(trecRunFile)
        self.reset(qrels)


    def _initDeltas(self, topicId, qrels):
        self.deltas[topicId] = {}
        entries = self.getEntriesBy(topicId)
        #initialize with precision
        nRelevant = 0
        for rank, (docId, _, _ ) in enumerate(entries, start=1):
            if docId in self.relevants[topicId]:
                nRelevant += 1
            elif not qrels.isJudged(topicId, docId):
                self.deltas[topicId][docId] = (nRelevant+1) / rank

        incPrecUnder = 0
        for (rank, (docId,_, _ )) in reversed( list(enumerate(entries, start=1)) ):
#            if docId == newReldocId: break #don't update anymore: above nothing changes

            if docId in self.relevants[topicId]:
                incPrecUnder += 1/rank
            elif not qrels.isJudged(topicId, docId):
                self.deltas[topicId][docId] += incPrecUnder

    def updateRelevant(self, topicId, docId, qrels):
        self.relevants[topicId].add(docId)
        self.unjudgedList[topicId] = [(d, r)
                                      for (d, r) in self.unjudgedList[topicId]
                                      if d != docId ]
        self._initDeltas(topicId, qrels)

    def keepOnly(self, topicIdsToKeep):
        """Keeps only entries for specified topicIds"""
        topicsToDel = self.getTopicIds() - topicIdsToKeep
        for topicToRemove in topicsToDel:
            del self.entries[topicToRemove]
            del self.deltas[topicToRemove]
            del self.unjudgedList[topicToRemove]
            del self.docSet[topicToRemove]
            del self.relevants[topicToRemove]

# CERun

def _selectBestDocToJudge(baselineCERun, newCERun, topicId):
    maxIncrement = -1
    bestDoc = newCERun.unjudgedList[topicId][0]
    for (docId, rank) in newCERun.unjudgedList[topicId]:
        if docId not in baselineCERun.docSet[topicId]\
        and newCERun.deltas[topicId][docId] >= maxIncrement:
            return (docId, rank)

        if docId in baselineCERun.docSet[topicId] and\
           newCERun.deltas[topicId][docId] - baselineCERun.deltas[topicId][docId] > maxIncrement:
            maxIncrement = newCERun.deltas[topicId][docId] - baselineCERun.deltas[topicId][docId]
            bestDoc = (docId, rank)
    return bestDoc

def oppNumRelevant(improvement, baselineCERun, newCERun, qrels_final, topicId):
    qrels = QRels(qrels_final.allJudgements, deepCopy=True)
    baseAPnum = evaluate(baselineCERun, qrels, avgPrec, True)[1][topicId] * qrels.getNRelevant(topicId)
    newAPnum =  evaluate(newCERun, qrels, avgPrec, True)[1][topicId] * qrels.getNRelevant(topicId)

    imp = (newAPnum - baseAPnum) / baseAPnum if baseAPnum > 0 else newAPnum
    judgDocs = []
    while imp < improvement and len(newCERun.unjudgedList[topicId]) > 0:
        docId, rank = _selectBestDocToJudge(baselineCERun, newCERun, topicId)
        baseAPnum += baselineCERun.deltas[topicId][docId] if docId in baselineCERun.deltas[topicId] else 0
        newAPnum += newCERun.deltas[topicId][docId]
        imp = (newAPnum - baseAPnum) / baseAPnum
        baselineCERun.updateRelevant(topicId, docId)
        newCERun.updateRelevant(topicId, docId)
        judgDocs.append(docId)
    return (judgDocs, imp)

def avgOppNumRelevants(improvement, baselineCERun, newCERun, qrels_final):
    """
    Returns a pair (avgJudg, avgImprovement) where
    - avgJudg is the average number of judgments (over topics) to get improvement
    - avgImprovement is the average improvement gotten while trying to reach improvement
    :type baselineCERun: CERun
    :type newCERun: CERun
    :type qrels_final: QRels
    """
    judgmentsImprovements = { topicId: oppNumRelevant(improvement, baselineCERun, newCERun, qrels_final, topicId)
                        for topicId in newCERun.getTopicIds() }
    # handle all topics that are in baseline but not in newrun
    for topicId in baselineCERun.getTopicIds() - newCERun.getTopicIds():
        judgmentsImprovements[topicId] = ([], 0)
        # means that if for some topic there is no entry then 0 improvement and 0 judgments
    #computing avg improvement
    improvements = [ imp for (_, imp) in judgmentsImprovements.values() ]
    avgImprovement = sum(improvements) / len(improvements)
    njudg = [ len(judg) for (judg, _) in judgmentsImprovements.values() ]
    avgJudg = sum(njudg) / len(njudg)
    return (avgJudg, avgImprovement)

def _uopPooling_singleTopic_fixedJudgments(maxJudgments, baselineCERun, newCERun, qrels_final, topicId):
     qrels = QRels(qrels_final.allJudgements, deepCopy=True)

     judgDocs = []
     nJudgDocs = 0
     while nJudgDocs < maxJudgments and len(newCERun.unjudgedList[topicId]) > 0:
         docId, rank = _selectBestDocToJudge(baselineCERun, newCERun, topicId)
         baselineCERun.updateRelevant(topicId, docId, qrels)
         newCERun.updateRelevant(topicId, docId, qrels)
         judgDocs.append( (docId, rank) )
         nJudgDocs += 1
     return judgDocs

def _uopPooling_singleTopic_APImprovement(maxJudgments, apImprovement, baselineCERun, newCERun, qrels_final, topicId):
    qrels = QRels(qrels_final.allJudgements, deepCopy=True)

    baseAPnum = evaluate(baselineCERun, qrels, avgPrec, True)[1][topicId] * qrels.getNRelevant(topicId)
    newAPnum = evaluate(newCERun, qrels, avgPrec, True)[1][topicId] * qrels.getNRelevant(topicId)

    imp = (newAPnum - baseAPnum) / baseAPnum if baseAPnum > 0 else newAPnum
    judgDocs = []
    nJudgDocs = 0
    while nJudgDocs < maxJudgments and imp < apImprovement and len(newCERun.unjudgedList[topicId]) > 0:
        docId, rank = _selectBestDocToJudge(baselineCERun, newCERun, topicId)
        baseAPnum += baselineCERun.deltas[topicId][docId] if docId in baselineCERun.deltas[topicId] else 0
        newAPnum += newCERun.deltas[topicId][docId]
        imp = (newAPnum - baseAPnum) / baseAPnum if baseAPnum > 0 else newAPnum
        baselineCERun.updateRelevant(topicId, docId, qrels)
        newCERun.updateRelevant(topicId, docId, qrels)
        judgDocs.append((docId, rank))
        nJudgDocs += 1
    return (judgDocs, imp)

def opportunisticPooling_fixedJudgments(maxJudgmentsPertopic, baselineCERun, newCERun, qrels_final):
    """
    :type baselineCERun: CERun
    :type newCERun: CERun
    :type qrels_final: QRels
    Returns a dictionary d[topicId] = set(docs)
    """
    return { topicId: _uopPooling_singleTopic_fixedJudgments(maxJudgmentsPertopic, baselineCERun, newCERun, qrels_final, topicId)
                        for topicId in newCERun.getTopicIds() }

def opportunisticPooling_APImprovement(improvement, maxJudgmentsPertopic, baselineCERun, newCERun, qrels_final):
    """
    :type baselineCERun: CERun
    :type newCERun: CERun
    :type qrels_final: QRels
    Returns a dictionary d[topicId] = ( set(docs), improvement )
    """
    return { topicId: _uopPooling_singleTopic_APImprovement(maxJudgmentsPertopic, improvement,
        baselineCERun, newCERun, qrels_final, topicId)
             for topicId in newCERun.getTopicIds()}